package com.javarush.task.task28.task2810.model;

import com.javarush.task.task28.task2810.vo.Vacancy;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MoikrugStrategy implements Strategy {
    private static final String URL_FORMAT= "https://moikrug.ru/vacancies?q=java+%s&page=%d";
    @Override
    public List<Vacancy> getVacancies(String searchString) {
        List<Vacancy> vacancyList = new ArrayList<Vacancy>();
        int pageNum = 0;
        Document document = null;
        while (true){
            try{

                document = getDocument(searchString,pageNum);
            }catch (IOException ex){
                ex.printStackTrace();
            }
            Elements vacancies = document.getElementsByClass("job");
            if(vacancies.size()==0) break;
            for (Element element:
                 vacancies) {
                if (element !=null){
                    Vacancy vacancy = new Vacancy();
                    vacancy.setTitle(element.getElementsByAttributeValue("class", "title").text());
                    vacancy.setCompanyName(element.getElementsByAttributeValue("class", "company_name").text());
                    vacancy.setSiteName(URL_FORMAT);
                    vacancy.setUrl("https://moikrug.ru" + element.select("a[class=job_icon]").attr("href"));
                    String salary = element.getElementsByAttributeValue("class", "salary").text();
                    String location = element.getElementsByAttributeValue("class", "location").text();
                    vacancy.setSalary(salary.length()==0?"":salary);
                    vacancy.setCity(location.length()==0?"":location);
                    vacancyList.add(vacancy);
                }
            }
            pageNum++;
        }
        return vacancyList;
    }

    protected Document getDocument(String searchString, int pageNum) throws IOException {
        String url = String.format(URL_FORMAT, searchString, pageNum);
        return Jsoup.connect(url)
                .userAgent("Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36")
                .timeout(5000)
                .referrer("http://google.ru")
                .get();
    }
}

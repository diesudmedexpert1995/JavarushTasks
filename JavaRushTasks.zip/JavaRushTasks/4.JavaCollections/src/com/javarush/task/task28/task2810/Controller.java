package com.javarush.task.task28.task2810;

import com.javarush.task.task28.task2810.model.Model;
import com.javarush.task.task28.task2810.model.Provider;
import com.javarush.task.task28.task2810.vo.Vacancy;

import java.util.ArrayList;
import java.util.Arrays;

public class Controller {
    private Model model;

    public Controller(Model model) throws IllegalArgumentException {
        if(model==null) throw new IllegalArgumentException("Illegal argument");
        this.model = model;
    }
    public void onCitySelect(String cityName){
        this.model.selectCity(cityName);
    }
}

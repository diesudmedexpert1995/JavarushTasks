package com.javarush.task.task28.task2810.model;

import com.javarush.task.task28.task2810.vo.Vacancy;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HHStrategy implements Strategy {
    private static final String URL_FORMAT = "http://hh.ua/search/vacancy?text=java+%s&page=%d";
  //  private static final String URL_FORMAT = "https://javarush.ru/testdata/big28data.html";

    @Override
    public List<Vacancy> getVacancies(String searchString) {
        List<Vacancy> vacancyList = new ArrayList<Vacancy>();
        int pageNum = 0;
        Document document = null;
        /*while (true){
            try{

                document = getDocument(searchString,pageNum);
            }catch (IOException ex){
                ex.printStackTrace();
            }
            Elements vacancies = document.getElementsByClass("job");
            if(vacancies.size()==0) break;
            for (Element element:
                 vacancies) {
                if (element !=null){
                    Vacancy vacancy = new Vacancy();
                    vacancy.setTitle(element.getElementsByAttributeValue("class", "title").text());
                    vacancy.setCompanyName(element.getElementsByAttributeValue("class", "company_name").text());
                    vacancy.setSiteName(URL_FORMAT);
                    vacancy.setUrl("https://moikrug.ru" + element.select("a[class=job_icon]").attr("href"));
                    String salary = element.getElementsByAttributeValue("class", "salary").text();
                    String location = element.getElementsByAttributeValue("class", "location").text();
                    vacancy.setSalary(salary.length()==0?"":salary);
                    vacancy.setCity(location.length()==0?"":location);
                    vacancyList.add(vacancy);
                }
            }
            pageNum++;
        }*/
        try {

            while (true) {
                //Получаем документ для парсинга и увеличиваем счетчик страниц
                Document doc = getDocument(searchString, pageNum++);

                //делаем выборку с указанными аттрибутами
                Elements elements = doc.getElementsByAttributeValue("data-qa", "vacancy-serp__vacancy");

                //Если вакансий нет - выходим из цикла
                if (elements.size() == 0) break;

                //парсим
                for (Element element : elements) {

                    //создаем новую вакансию
                    Vacancy vacancy = new Vacancy();

                    Element titleE = element.getElementsByAttributeValue("data-qa", "vacancy-serp__vacancy-title").first();
                    vacancy.setTitle(titleE.text());

                    Element salaryE = element.getElementsByAttributeValue("data-qa", "vacancy-serp__vacancy-compensation").first();
                    if (salaryE != null) {
                        vacancy.setSalary(salaryE.text());
                    } else {
                        vacancy.setSalary("");
                    }

                    Element cityE = element.getElementsByAttributeValue("data-qa", "vacancy-serp__vacancy-address").first();
                    vacancy.setCity(cityE.text());

                    Element companyNameE = element.getElementsByAttributeValue("data-qa","vacancy-serp__vacancy-employer").first();
                    vacancy.setCompanyName(companyNameE.text());

                    vacancy.setUrl(element.getElementsByAttributeValue("data-qa", "vacancy-serp__vacancy-title").attr("href"));

                    vacancy.setSiteName(URL_FORMAT);

                    vacancyList.add(vacancy);

                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return vacancyList;
    }

    protected Document getDocument(String searchString, int page) throws IOException {
        String url = String.format(URL_FORMAT,searchString,page);
        return Jsoup.connect(url).userAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36").referrer("https://www.google.de").get();
    }
}

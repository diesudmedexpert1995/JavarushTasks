package com.javarush.task.task33.task3310;

import com.javarush.task.task33.task3310.strategy.HashMapStorageStrategy;
import com.javarush.task.task33.task3310.strategy.StorageStrategy;

import java.util.*;

public class Solution {
   public static Set<Long> getIds(Shortener shortener, Set<String> strings){
     Set<Long> idsSet = new HashSet();
       for (String stringsElement: strings) {
           idsSet.add(shortener.getId(stringsElement));
       }
     return idsSet;
   }
    public static Set<String> getStrings(Shortener shortener, Set<Long> keys){
       Set<String> stringsSet = new HashSet<String>();
        for (Long key: keys) {
            stringsSet.add(shortener.getString(key));
        }
       return stringsSet;
    }
    public static void testStrategy(StorageStrategy strategy, long elementsNumber)
    {
        System.out.println(strategy.getClass().getSimpleName());
        Set<String> testForSet = new HashSet<String>();
        //Long[] elements = new Long[(int) elementsNumber];
        for (int i = 0; i <elementsNumber; i++) {
            testForSet.add(Helper.generateRandomString());
        }


        Shortener testExample = new Shortener(strategy);
        Date startDateTime = new Date();
        Set<Long> ids = getIds(testExample, testForSet);
        Date finishDateTime = new Date();

        long deltaTime = finishDateTime.getTime() - startDateTime.getTime();
        Helper.printMessage(Long.toString(deltaTime));

        //6.2.3.5. Замерять и выводить время необходимое для отработки метода getStrings для заданной стратегии
        startDateTime = new Date();
        Set<String> strs = getStrings(testExample, ids);
        finishDateTime = new Date();

        deltaTime = finishDateTime.getTime() - startDateTime.getTime();
        Helper.printMessage(Long.toString(deltaTime));

        if (testForSet.equals(strs))
            Helper.printMessage("Тест пройден.");
        else
            Helper.printMessage("Тест не пройден.");

    }
        public static void main(String[] args) {
        StorageStrategy storageStrategy1 = new HashMapStorageStrategy();
        testStrategy(storageStrategy1,10000);
    }
}

package com.javarush.task.task33.task3305;

public class Car extends Auto {
}
package com.javarush.task.task20.task2028;

import java.io.Serializable;
import java.util.*;

/* 
Построй дерево(1)
*/
public class CustomTree extends AbstractList<String> implements Cloneable, Serializable {
    Entry<String> root =new Entry<String>("0");
    public static void main(String[] args) {
        List<String> list = new CustomTree();
        for (int i = 1; i < 16; i++) {
            list.add(String.valueOf(i));
        }
        //System.out.println("Expected 3, actual is " + ((CustomTree) list).getParent("8"));
        list.remove("5");
        //System.out.println("Expected null, actual is " + ((CustomTree) list).getParent("11"));
    }

    @Override
    public String get(int i) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int size() {
        int size = -1;
        Queue<Entry<String>> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            Entry<String> currentNode = queue.poll();
            size++;
            if (currentNode.leftChild != null) {
                queue.offer(currentNode.leftChild);
            }
            if (currentNode.rightChild != null) {
                queue.offer(currentNode.rightChild);
            }
        }
        return size;
    }

    @Override
    public boolean add(String s) {
        Queue<Entry<String>> queue = new LinkedList<Entry<String>>(); //создаем обьект очередь
        queue.add(root);// добавляем в очередь корневой елемент
        while (!queue.isEmpty()) // цикл будет работать пока очередь не пуста
        {
            Entry<String> currentNode = queue.poll();// вычисляем текущий елемент

            currentNode.checkChildren();// проверяем его детей
            if (currentNode.isAvailableToAddChildren()){// если есть возможность добавления элемента
                if (currentNode.availableToAddLeftChildren) //если есть возможность добавления элемента "влево"
                {
                    currentNode.leftChild = new Entry<>(s);//создаем и вставляем
                    currentNode.leftChild.parent = currentNode;
                    return true;
                }
                if (currentNode.availableToAddRightChildren)//если есть возможность добавления элемента "вправо"
                {
                    currentNode.rightChild = new Entry<>(s);
                    currentNode.rightChild.parent = currentNode;
                    return true;
                }
            }
            else{
                 if (currentNode.leftChild!=null){
                     queue.offer(currentNode.leftChild);
                 }
                 if (currentNode.rightChild!=null){
                     queue.offer(currentNode.rightChild);
                 }
            }
        }
        return  false;
    }

    @Override
    public String set(int i, String s) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void add(int i, String s) {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean remove(Object o) {
        String s = (String) o;
        Queue<Entry<String>> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            Entry<String> currentNode = queue.poll();
            if (currentNode.leftChild != null) {
                if (currentNode.leftChild.elementName.equals(s)){
                    currentNode.leftChild = null;
                    return true;
                }
                queue.offer(currentNode.leftChild);
            }
            if (currentNode.rightChild != null) {
                if (currentNode.rightChild.elementName.equals(s)){
                    currentNode.rightChild = null;
                    return true;
                }
                queue.offer(currentNode.rightChild);
            }
        }
        return false;
    }

    String getParent(String entryName){
        Queue<Entry<String>> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            Entry<String> currentNode = queue.poll();
            if (currentNode.elementName.equals(entryName)){
                return currentNode.parent.elementName;
            } else {
                if (currentNode.leftChild != null) {
                    queue.offer(currentNode.leftChild);
                }
                if (currentNode.rightChild != null) {
                    queue.offer(currentNode.rightChild);
                }
            }
        }
        return null;
    }

    @Override
    public boolean addAll(int i, Collection<? extends String> collection) {
        throw new UnsupportedOperationException();
    }

    @Override
    public List<String> subList(int i, int i1) {
        throw new UnsupportedOperationException();
    }

    @Override
    protected void removeRange(int i, int i1) {
        throw new UnsupportedOperationException();
    }
    static class Entry<T> implements Serializable{
        String elementName;
        int lineNumber;
        boolean availableToAddLeftChildren, availableToAddRightChildren;
        Entry<T> parent, leftChild, rightChild;

        public Entry(String elementName) {
            this.elementName = elementName;
            this.availableToAddLeftChildren=true;
            this.availableToAddRightChildren=true;
        }
        public void checkChildren()
        {
            if (leftChild!=null) this.availableToAddLeftChildren=false;
            if (rightChild!=null) this.availableToAddRightChildren=false;
        }
        public boolean isAvailableToAddChildren()
        {
            return availableToAddRightChildren||availableToAddLeftChildren;
        }

    }
}

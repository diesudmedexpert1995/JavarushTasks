package com.javarush.task.task32.task3206;

public interface Big extends Item {
}
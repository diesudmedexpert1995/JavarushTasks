package com.javarush.task.task32.task3210;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.sql.Struct;

/* 
Используем RandomAccessFile
*/

public class Solution {
    public static void main(String... args) throws IOException {
        String fileName = args[0];
        int number = Integer.parseInt(args[1]);
        String text = args[2];
        try(RandomAccessFile randomAccessFile = new RandomAccessFile(fileName,"rw")) {
            byte[] buffer = new byte[text.length()];
            randomAccessFile.seek(number);
            randomAccessFile.read(buffer,0,buffer.length);
            String lineFromFile = convertByteToString(buffer);
            String storeToFile = lineFromFile.equals(text) ? "true" : "false";
            randomAccessFile.seek(randomAccessFile.length());
            randomAccessFile.write(storeToFile.getBytes());
        }
    }
    public static String convertByteToString(byte readBytes[])
    {
        return new String(readBytes);
    }
}

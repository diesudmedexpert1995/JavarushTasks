package com.javarush.task.task32.task3201;

import java.io.FileNotFoundException;
import java.io.RandomAccessFile;
import java.util.Random;

/*
Запись в существующий файл
*/
public class Solution {
    public static void main(String... args) {
        String fileName = args[0];
        long position = Integer.parseInt(args[1]);
        String text = args[2];
        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(fileName,"rw");
            position = position>randomAccessFile.length()?randomAccessFile.length():position;
            randomAccessFile.seek(position);
            randomAccessFile.write(text.getBytes());
            randomAccessFile.close();
        }catch (Exception ex)
        {
            System.err.println(ex.getMessage());
        }
    }
}

package com.javarush.task.task31.task3109;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FilterReader;
import java.io.IOException;
import java.util.Properties;

/* 
Читаем конфиги
*/
public class Solution {
    public static void main(String[] args) {
        Solution solution = new Solution();
        Properties properties = solution.getProperties("src/com/javarush/task/task31/task3109/properties.xml");
        properties.list(System.out);

        properties = solution.getProperties("src/com/javarush/task/task31/task3109/properties.txt");
        properties.list(System.out);

        properties = solution.getProperties("src/com/javarush/task/task31/task3109/notExists");
        properties.list(System.out);
    }

    public Properties getProperties(String fileName){
        Properties props = new Properties();
        int pos = fileName.lastIndexOf(".");
        String ext = pos>=0?fileName.substring(pos):" ";

        try {
            switch (ext)
            {
                case ".xml":{
                   FileInputStream fis = new FileInputStream(fileName);
                   props.loadFromXML(fis);
                   fis.close();
                   break;
                }
                case ".txt":{
                    FileReader fr = new FileReader(fileName);
                    props.load(fr);
                    fr.close();
                    break;
                }
                default:{
                    FileInputStream fis = new FileInputStream(fileName);
                    props.load(fis);
                    fis.close();
                    break;
                   }

            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return props;
        }
        return props;
    }
}

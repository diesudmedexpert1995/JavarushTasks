package com.javarush.task.task37.task3709.connectors;

public interface Connector {
    void connect();
}

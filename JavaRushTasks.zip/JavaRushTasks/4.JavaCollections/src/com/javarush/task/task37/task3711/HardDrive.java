package com.javarush.task.task37.task3711;

public class HardDrive {
    void storeData() {
        System.out.println("Storing data to HDD...");
    }
}

package com.javarush.task.task37.task3711;

public class CPU {
    void calculate() {
        System.out.println("Making some CPU calculations...");
    }
}

package com.javarush.task.task37.task3702;

public interface AbstractFactory {
    Human getPerson(int age);
}

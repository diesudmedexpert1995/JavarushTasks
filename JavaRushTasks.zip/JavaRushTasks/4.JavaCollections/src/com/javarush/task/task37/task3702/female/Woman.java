package com.javarush.task.task37.task3702.female;

import com.javarush.task.task37.task3702.Human;

public class Woman implements Human {
    @Override
    public String toString() {
        return "Woman{}";
    }
}

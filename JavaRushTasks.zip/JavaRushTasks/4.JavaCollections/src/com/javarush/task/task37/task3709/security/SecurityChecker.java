package com.javarush.task.task37.task3709.security;

public interface SecurityChecker {
    boolean performSecurityCheck();
}

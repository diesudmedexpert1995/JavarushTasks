package com.javarush.task.task35.task3507.data;

public class Elephant {
    private Elephant() {
    }
}
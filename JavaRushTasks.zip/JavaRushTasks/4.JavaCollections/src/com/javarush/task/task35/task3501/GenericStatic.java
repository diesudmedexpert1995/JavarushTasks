package com.javarush.task.task35.task3501;

public class GenericStatic {
    public static <T extends Object> T someStaticMethod(Object genericObject) {
        System.out.println(genericObject);
        return (T) genericObject;
    }
}

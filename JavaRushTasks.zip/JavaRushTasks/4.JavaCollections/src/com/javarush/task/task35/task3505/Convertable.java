package com.javarush.task.task35.task3505;

public interface Convertable<Key> {
    Key getKey();
}

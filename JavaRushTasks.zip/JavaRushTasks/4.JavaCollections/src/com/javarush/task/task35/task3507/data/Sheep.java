package com.javarush.task.task35.task3507.data;

import com.javarush.task.task35.task3507.Animal;

public class Sheep implements Animal {
    private Sheep() {
    }

    public Sheep(Integer integer) {
    }
}
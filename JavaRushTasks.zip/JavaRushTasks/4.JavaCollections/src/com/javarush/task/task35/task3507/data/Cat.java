package com.javarush.task.task35.task3507.data;

import com.javarush.task.task35.task3507.Animal;

public class Cat implements Animal {
    public Cat() {
    }
}

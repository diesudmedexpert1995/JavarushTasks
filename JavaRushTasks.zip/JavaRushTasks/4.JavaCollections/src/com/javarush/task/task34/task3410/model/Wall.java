package com.javarush.task.task34.task3410.model;

import java.awt.*;

public class Wall extends CollisionObject {
    public Wall(int x, int y) {
        super(x, y);
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.GRAY);
        int leftUpperCornerX = getX()-getWidth()/2;
        int leftUpperCornerY = getY()-getHeight()/2;
        g.drawRect(leftUpperCornerX,leftUpperCornerY,getWidth(),getHeight());
        g.fillRect(leftUpperCornerX,leftUpperCornerY,getWidth(),getHeight());
    }
}

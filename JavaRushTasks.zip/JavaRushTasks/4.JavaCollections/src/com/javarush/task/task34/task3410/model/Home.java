package com.javarush.task.task34.task3410.model;

import java.awt.*;

public class Home extends GameObject {
    public Home(int x, int y) {
        super(x, y);
        setWidth(2);
        setHeight(2);
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.RED);
        int leftUpperCornerX = getX()-getWidth()/2;
        int leftUpperCornerY = getY()-getHeight()/2;
        g.drawRect(leftUpperCornerX,leftUpperCornerY,getWidth(),getHeight());
        g.fillRect(leftUpperCornerX,leftUpperCornerY,getWidth(),getHeight());
    }
}

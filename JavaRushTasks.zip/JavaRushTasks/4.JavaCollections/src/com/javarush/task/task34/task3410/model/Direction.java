package com.javarush.task.task34.task3410.model;

public enum Direction {
    LEFT,
    RIGHT,
    UP,
    DOWN
}

package com.javarush.task.task26.task2613;

import com.javarush.task.task26.task2613.exception.InterruptOperationException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ResourceBundle;

public class ConsoleHelper {
    private static ResourceBundle res = ResourceBundle.getBundle(CashMachine.RESOURCE_PATH + ".common_en");
    private static BufferedReader bis = new BufferedReader(new InputStreamReader(System.in));
    public static void writeMessage(String message){
        System.out.println(message);
    }
    public static String readString() throws InterruptOperationException {
        String res="";
        try {
            res = bis.readLine();
            if (res.equalsIgnoreCase("exit")) throw new InterruptOperationException();
        } catch (IOException ignored) {
        }
        return res;
    }
    public static String askCurrencyCode() throws InterruptOperationException {
        String currencyCode=null;
        writeMessage("Please, choice currency code: ");
        while (true){
            currencyCode=readString();
            if (currencyCode.length()==3)break;
            else
            {
                writeMessage("Error, Please choice again:");
            }
        }
        return currencyCode.toUpperCase();
    }
    public static String[] getValidTwoDigits(String currencyCode) throws InterruptOperationException {
        writeMessage("Input nominal and total");
        String[] input ;
        while (true){
            input = readString().split(" ");
            int nominal =0;
            int total = 0;
            try{
                nominal = Integer.parseInt(input[0]);
                total = Integer.parseInt(input[1]);
            }catch (Exception ex)
            {
                writeMessage("Error, Please try again");
                continue;
            }
            if (nominal<=0||total<=0){
                writeMessage("Error, Please try again");
                continue;
            }
            break;
        }
        return  input;
    }
    public static Operation askOperation() throws InterruptOperationException {
        Operation operation=null;
        while (true){
            int num = Integer.parseInt(readString());
            operation = Operation.getAllowableOperationByOrdinal(num);
            break;
        }
        return operation;
    }
    public static void printExitMessage() {
        ConsoleHelper.writeMessage(res.getString("the.end"));
    }
}

package com.javarush.task.task26.task2613.exception;

public class InterruptOperationException extends Exception {
}

package com.javarush.task.task38.task3809;

public class IncorrectAccount {
    @LongPositive
    private String amountString;
}
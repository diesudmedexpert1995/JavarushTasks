package com.javarush.task.task38.task3803;

/* 
Runtime исключения (unchecked exception)
*/

import com.sun.org.apache.xpath.internal.operations.String;

public class VeryComplexClass {
    public void methodThrowsClassCastException() throws ClassCastException {
            Object s = new Character('*');
            System.out.println((Byte)s);
    }

    public void methodThrowsNullPointerException() throws NullPointerException{
            Object object = null;
            System.out.println(object.hashCode());
    }

    public static void main(String[] args) {

    }
}

package com.javarush.task.task38.task3801;

public class NameIsNullException extends Exception {
}

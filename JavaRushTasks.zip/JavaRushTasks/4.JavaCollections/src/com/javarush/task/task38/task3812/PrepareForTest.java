package com.javarush.task.task38.task3812;

public @interface PrepareForTest {
}

package com.javarush.task.task38.task3804;

public class ExceptionFactory {
    public static Throwable getException(Enum type) {
        if (type != null) {
            if (type instanceof ExceptionApplicationMessage) {
                return new Exception(type.name().charAt(0) + type.name().substring(1).toLowerCase().replace("_", " "));
            }
            else if (type instanceof ExceptionDBMessage) {
                return new RuntimeException(type.name().charAt(0) + type.name().substring(1).toLowerCase().replace("_", " "));
            }
            else if (type instanceof ExceptionUserMessage) {
                return new Error(type.name().charAt(0) + type.name().substring(1).toLowerCase().replace("_", " "));
            }
        }
        return new IllegalArgumentException();
    }
}

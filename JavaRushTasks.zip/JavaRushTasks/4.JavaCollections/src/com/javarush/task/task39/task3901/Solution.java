package com.javarush.task.task39.task3901;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/* 
Уникальные подстроки
*/
public class Solution {
    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Please input your string: ");
        String s = bufferedReader.readLine();

        System.out.println("The longest unique substring length is: \n" + lengthOfLongestUniqueSubstring(s));
    }

    public static int lengthOfLongestUniqueSubstring(String s) {
        if (s == null || s.length()==0)return 0;
        ArrayList<Integer> lengthList = new ArrayList<>();
        for (int ii = 0; ii < s.length() ; ii++) {
            String subs = s.substring(ii,s.length()) ;
            StringBuffer noRepeat = new StringBuffer();
            noRepeat.append(subs.charAt(0));
            exit:
            for (int i = 1; i <subs.length() ; i++) {
                for (int j = 0; j < noRepeat.length(); j++)
                    if (noRepeat.charAt(j)==subs.charAt(i))
                        break exit;
                   noRepeat.append(subs.charAt(i));
            }
            lengthList.add(noRepeat.toString().length());
        }
        return Collections.max(lengthList);
    }
}

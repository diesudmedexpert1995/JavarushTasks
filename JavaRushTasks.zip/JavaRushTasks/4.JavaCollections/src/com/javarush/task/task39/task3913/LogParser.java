package com.javarush.task.task39.task3913;

public class LogParser {
}
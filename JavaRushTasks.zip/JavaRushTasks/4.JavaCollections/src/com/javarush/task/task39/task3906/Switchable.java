package com.javarush.task.task39.task3906;

public interface Switchable {
    boolean isOn();
    void turnOn();
    void turnOff();
}

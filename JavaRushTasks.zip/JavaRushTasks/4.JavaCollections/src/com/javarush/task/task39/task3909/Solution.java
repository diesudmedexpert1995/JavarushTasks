package com.javarush.task.task39.task3909;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

/*
Одно изменение
*/
public class Solution {
    public static void main(String[] args) {
        System.out.println(isOneEditAway("", "")); // true
        System.out.println(isOneEditAway("", "m")); //true
        System.out.println(isOneEditAway("m", "")); //true
        //System.out.println(isOneEditAway("m", null)); //
        System.out.println("------");
        System.out.println(isOneEditAway("mama", "ramas")); //false
        System.out.println(isOneEditAway("mamas", "rama")); //false
        System.out.println(isOneEditAway("rama", "mama")); //true
        System.out.println(isOneEditAway("mama", "dama")); //true
        System.out.println(isOneEditAway("ama", "mama"));  //true
        System.out.println(isOneEditAway("mama", "ama")); //true
    }

    public static boolean isOneEditAway(String first, String second) {
        if (first.equals("") && second.equals("")) return true;
        if(first.equals(second)) return true;
        StringBuffer stringBuffer1 = (first.length() >= second.length()) ? new StringBuffer(first) : new StringBuffer(second);
        StringBuffer stringBuffer2 = (first.length() < second.length()) ? new StringBuffer(first) : new StringBuffer(second);
        for (int i = 0; i < stringBuffer2.length(); i++) {
            int pos = stringBuffer1.indexOf(String.valueOf(stringBuffer2.charAt(i)));
            if (pos != -1) stringBuffer1.deleteCharAt(pos);
        }
        if (stringBuffer1.length() == 1) return true;
        return false;
    }
}